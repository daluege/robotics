# line_follower
an example to read the image from the camera
